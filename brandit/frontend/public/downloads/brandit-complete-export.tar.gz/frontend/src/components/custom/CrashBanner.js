import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';

export const CrashBanner = ({ products }) => {
  const crashProducts = products.filter(p => p.crash_sale_active);
  
  if (crashProducts.length === 0) return null;
  
  return (
    <motion.div
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-[#FF3B30] text-white py-3 overflow-hidden"
      data-testid="crash-banner"
    >
      <div className="flex items-center justify-center gap-3 animate-pulse">
        <AlertTriangle size={20} />
        <div className="font-heading font-bold text-sm md:text-base uppercase tracking-wider">
          CRASH SALE ACTIVE: {crashProducts.length} Products at 50% OFF!
        </div>
        <AlertTriangle size={20} />
      </div>
    </motion.div>
  );
};